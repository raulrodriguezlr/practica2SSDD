package es.coderurjc.apirestreservabicicletas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestReservaBicicletasApplicationTests {

	@Test
	void contextLoads() {
	}

}
